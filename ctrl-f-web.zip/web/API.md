# Backend contract (for Luis)

The website expects these from the FastAPI server on the same address that serves the `web/` folder (e.g. `app.mount("/", StaticFiles(directory="web", html=True))`, mounted **after** the API routes so they take priority).

Bounding boxes are normalized `[x1, y1, x2, y2]` in 0–1, matching `BoundingBox` in AGENTS.md. Times are ISO 8601 strings.

## HTTP

| Method | Path | Body / returns |
|---|---|---|
| GET | `/items` | `[Item, ...]`: everything in memory (the dashboard also uses this to detect that the backend is up) |
| GET | `/video` | MJPEG stream (`multipart/x-mixed-replace`) with boxes drawn on |
| POST | `/ask` | `{"text": "where are my keys"}`: typed question |
| POST | `/listen` | no body: start push-to-talk recording on the backend's mic |
| GET | `/tracked` | `{"items": [{"name": "keys", "enabled": true}, ...]}` |
| POST | `/tracked` | same shape: replace the tracked list. Enabled names should go to YOLO-World `set_classes()` |
| GET | `/snapshots/<file>` | saved JPEG crops (`Item.snapshot` points here) |
| POST | `/teach` | `{"name": "retainer case", "images": ["data:image/jpeg;base64,...", ...]}`: teach mode. 6 square 320px photos of the object from different angles, taken with the laptop webcam. Add it to the tracked list and to whatever the detector uses to recognize it (see below). Reply `{"ok": true}` |

`Item`:

```json
{ "name": "keys", "visible": true, "last_seen": "2026-10-17T14:15:02",
  "where": "left of the laptop", "snapshot": "/snapshots/keys_1415.jpg",
  "bbox": [0.16, 0.6, 0.27, 0.74] }
```

## WebSocket `/ws`

One JSON message per event:

```json
{"type": "item_update", ...Item}
{"type": "state", "state": "QUERYING", "heard": "where are my keys"}
{"type": "state", "state": "TRACKING", "target": "keys"}
{"type": "target", "name": "keys", "bbox": [0.16, 0.6, 0.27, 0.74]}
{"type": "state", "state": "REPORTING", "target": "keys", "result": "found", "message": "Your keys are left of the laptop."}
{"type": "state", "state": "REPORTING", "target": "glasses", "result": "hidden", "message": "Last seen at 12:16 AM, behind the monitor."}
{"type": "state", "state": "REPORTING", "result": "unknown", "message": "I haven't seen that yet."}
{"type": "target", "name": null, "bbox": null}
{"type": "state", "state": "IDLE"}
{"type": "tracked", "items": [{"name": "keys", "enabled": true}]}
{"type": "log", "text": "Keys went out of view"}
```

`state` values match `SystemState` in AGENTS.md: `IDLE`, `QUERYING`, `TRACKING`, `REPORTING`, `ERROR`.

Send `target` with a bbox when the laser starts aiming (the dashboard draws the beam), and `target` with `null` when it turns off.

## Teach mode notes (for Daniel)

The photos come from the laptop's built-in webcam; the room camera is a different camera. Things to know:

- **YOLO-World matches text, not photos.** Adding the name with `set_classes()` is the easy first step, but for odd objects the name alone may not be enough. Options that use the photos: run CLIP on the 6 photos, store the average embedding, and compare it with CLIP embeddings of the detector's crops (or of generic "object" detections); or Ultralytics' YOLOE, which accepts visual prompts.
- **Different viewpoint.** The laptop camera sees the object from the front, close up. The ceiling camera sees it from above and small. The UI tells people to turn the object while capturing; include a top-down angle. Expect to lower the match threshold for taught items.
- After `/teach` succeeds, send a `tracked` message over `/ws` so the dashboard updates.
