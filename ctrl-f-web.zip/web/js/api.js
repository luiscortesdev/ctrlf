// The ONLY file that talks to the backend.
// Live mode uses Luis's FastAPI endpoints (see API.md).
// If the backend isn't reachable, it falls back to mock mode so the
// dashboard still works for design and demos.

const listeners = { item: [], state: [], log: [], tracked: [], target: [], connection: [] };

export function on(event, fn) { listeners[event].push(fn); }
function emit(event, data) { listeners[event].forEach((fn) => fn(data)); }

export let mode = "connecting";

export async function connect() {
  const live = await backendReachable();
  mode = live ? "live" : "mock";
  emit("connection", mode);
  if (live) startLive(); else startMock();
  return mode;
}

async function backendReachable() {
  if (new URLSearchParams(location.search).has("mock")) return false;
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 1200);
    const res = await fetch("/items", { signal: ctrl.signal });
    clearTimeout(timer);
    return res.ok;
  } catch {
    return false;
  }
}

/* ---------------- Public actions ---------------- */

export function videoUrl() { return mode === "live" ? "/video" : null; }

export async function ask(text) {
  if (mode === "live") {
    await fetch("/ask", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ text }) });
  } else {
    mockAsk(text);
  }
}

// Push-to-talk: the backend records from its own mic and runs Whisper.
export async function listen() {
  if (mode === "live") {
    await fetch("/listen", { method: "POST" });
  } else {
    mockAsk("where are my keys?");
  }
}

export async function setTracked(items) {
  if (mode === "live") {
    await fetch("/tracked", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ items }) });
  } else {
    mock.tracked = items;
    emit("tracked", items);
    emit("log", { time: new Date(), text: `Now tracking: ${items.filter((i) => i.enabled).map((i) => i.name).join(", ")}` });
  }
}

// Teach mode: name + photos (JPEG data URLs) of a new object.
export async function teach(name, images) {
  if (mode === "live") {
    const res = await fetch("/teach", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name, images }) });
    if (!res.ok) throw new Error(`backend said ${res.status}`);
    return res.json().catch(() => ({}));
  }
  await wait(700);
  if (!mock.tracked.some((t) => t.name === name)) mock.tracked = [...mock.tracked, { name, enabled: true }];
  emit("tracked", mock.tracked);
  const item = { name, visible: true, last_seen: new Date().toISOString(), where: "just taught", snapshot: images[0], bbox: [0.42, 0.42, 0.58, 0.58] };
  mock.items[name] = item;
  emit("item", { type: "item_update", ...item });
  emit("log", { time: new Date(), text: `Learned "${name}" from ${images.length} photos` });
  return { ok: true };
}

/* ---------------- Live mode ---------------- */

async function startLive() {
  const [items, tracked] = await Promise.all([
    fetch("/items").then((r) => r.json()).catch(() => []),
    fetch("/tracked").then((r) => r.json()).catch(() => ({ items: [] })),
  ]);
  (Array.isArray(items) ? items : items.items || []).forEach((it) => emit("item", it));
  emit("tracked", tracked.items || []);

  const proto = location.protocol === "https:" ? "wss" : "ws";
  let retry = 1000;
  const open = () => {
    const ws = new WebSocket(`${proto}://${location.host}/ws`);
    ws.onopen = () => { retry = 1000; emit("connection", "live"); };
    ws.onmessage = (e) => {
      let msg;
      try { msg = JSON.parse(e.data); } catch { return; }
      if (msg.type === "item_update") emit("item", msg);
      else if (msg.type === "state") emit("state", msg);
      else if (msg.type === "target") emit("target", msg);
      else if (msg.type === "tracked") emit("tracked", msg.items);
      else if (msg.type === "log") emit("log", { time: new Date(msg.time || Date.now()), text: msg.text });
    };
    ws.onclose = () => {
      emit("connection", "reconnecting");
      setTimeout(open, retry);
      retry = Math.min(retry * 2, 8000);
    };
  };
  open();
}

/* ---------------- Mock mode ---------------- */

const mock = {
  tracked: [
    { name: "keys", enabled: true },
    { name: "wallet", enabled: true },
    { name: "earbuds case", enabled: true },
    { name: "glasses", enabled: true },
    { name: "water bottle", enabled: true },
    { name: "phone", enabled: false },
  ],
  items: {},
  busy: false,
};

function minutesAgo(m) { return new Date(Date.now() - m * 60000).toISOString(); }

function startMock() {
  const seed = [
    { name: "keys", visible: true, last_seen: minutesAgo(0), where: "left of the laptop", bbox: [0.16, 0.6, 0.27, 0.74] },
    { name: "wallet", visible: true, last_seen: minutesAgo(0), where: "right side of the desk", bbox: [0.72, 0.64, 0.84, 0.75] },
    { name: "earbuds case", visible: false, last_seen: minutesAgo(11), where: "in front of the laptop", bbox: [0.46, 0.72, 0.53, 0.8] },
    { name: "glasses", visible: false, last_seen: minutesAgo(47), where: "behind the monitor", bbox: [0.6, 0.3, 0.7, 0.38] },
    { name: "water bottle", visible: true, last_seen: minutesAgo(0), where: "far left of the desk", bbox: [0.08, 0.22, 0.17, 0.48] },
  ];
  seed.forEach((it) => { mock.items[it.name] = it; emit("item", { type: "item_update", ...it }); });
  emit("tracked", mock.tracked);
  emit("state", { type: "state", state: "IDLE" });
  emit("log", { time: new Date(), text: "Mock mode: backend not connected" });

  // Keep "seen now" items fresh and occasionally hide/show the wallet.
  setInterval(() => {
    Object.values(mock.items).forEach((it) => {
      if (it.visible) { it.last_seen = new Date().toISOString(); emit("item", { type: "item_update", ...it }); }
    });
  }, 5000);

  setInterval(() => {
    if (mock.busy) return;
    const w = mock.items.wallet;
    w.visible = !w.visible;
    w.last_seen = new Date().toISOString();
    emit("item", { type: "item_update", ...w });
    emit("log", { time: new Date(), text: w.visible ? "Wallet back in view" : "Wallet went out of view" });
  }, 22000);
}

function resolveTarget(text) {
  const t = text.toLowerCase();
  const names = Object.keys(mock.items).sort((a, b) => b.length - a.length);
  return names.find((n) => t.includes(n)) || names.find((n) => n.split(" ").some((w) => w.length > 3 && t.includes(w)));
}

function wait(ms) { return new Promise((r) => setTimeout(r, ms)); }

async function mockAsk(text) {
  if (mock.busy) return;
  mock.busy = true;
  emit("log", { time: new Date(), text: `Heard: "${text}"` });
  emit("state", { type: "state", state: "QUERYING", heard: text });
  await wait(700);

  const name = resolveTarget(text);
  const item = name && mock.items[name];

  if (!item) {
    emit("state", { type: "state", state: "REPORTING", result: "unknown", message: "I haven't seen that yet." });
    emit("log", { time: new Date(), text: "No match in memory" });
  } else if (!item.visible) {
    const when = new Date(item.last_seen).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
    emit("state", { type: "state", state: "REPORTING", target: name, result: "hidden", message: `Your ${name} ${name.endsWith("s") ? "are" : "is"} out of sight. Last seen at ${when}, ${item.where}.` });
    emit("log", { time: new Date(), text: `${cap(name)} hidden, showing last-seen snapshot` });
  } else {
    emit("state", { type: "state", state: "TRACKING", target: name });
    emit("target", { type: "target", name, bbox: item.bbox });
    emit("log", { time: new Date(), text: `Aiming laser at ${name}` });
    await wait(1600);
    emit("state", { type: "state", state: "REPORTING", target: name, result: "found", message: `Your ${name} ${name.endsWith("s") ? "are" : "is"} ${item.where}.` });
    emit("log", { time: new Date(), text: `Locked on ${name}` });
  }

  await wait(5000);
  emit("target", { type: "target", name: null, bbox: null });
  emit("state", { type: "state", state: "IDLE" });
  mock.busy = false;
}

function cap(s) { return s.charAt(0).toUpperCase() + s.slice(1); }
