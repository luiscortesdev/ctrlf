// Teach mode: hold an object up to the laptop's webcam, take a burst of
// photos from different angles, name it, and send it to the backend so the
// room camera can recognize it.

import * as api from "./api.js";
import * as sfx from "./sound.js";

const $ = (id) => document.getElementById(id);

const SHOTS = 6;          // photos per object
const SHOT_GAP = 450;     // ms between photos (time to turn the object)
const CROP_SIZE = 320;    // px, square crop sent to the backend
const GUIDE = 0.56;       // guide box width as a fraction of the preview (matches CSS)

const dialog = $("teach");
const video = $("teach-video");
const camSelect = $("teach-cam-select");
let stream = null;
let shots = [];
let busy = false;

export function initTeach() {
  $("teach-open").addEventListener("click", open);
  $("teach-close").addEventListener("click", close);
  dialog.addEventListener("close", stopCamera);
  camSelect.addEventListener("change", () => startCamera(camSelect.value));
  $("teach-capture").addEventListener("click", capture);
  $("teach-save").addEventListener("click", save);
  $("teach-name").addEventListener("input", updateSave);
}

async function open() {
  shots = [];
  renderShots();
  $("teach-name").value = "";
  $("teach-msg").textContent = "";
  updateSave();
  dialog.showModal();
  sfx.unlock();
  await startCamera(localStorage.getItem("ctrlf-teach-cam") || undefined);
  await listCameras();
}

function close() { dialog.close(); }

function stopCamera() {
  if (stream) stream.getTracks().forEach((t) => t.stop());
  stream = null;
}

async function startCamera(deviceId) {
  stopCamera();
  try {
    stream = await navigator.mediaDevices.getUserMedia({
      video: deviceId ? { deviceId: { exact: deviceId }, width: 1280, height: 960 } : { width: 1280, height: 960 },
      audio: false,
    });
    video.srcObject = stream;
    $("teach-nocam").hidden = true;
    const id = stream.getVideoTracks()[0].getSettings().deviceId;
    if (id) { try { localStorage.setItem("ctrlf-teach-cam", id); } catch {} }
  } catch {
    $("teach-nocam").hidden = false;
  }
}

// The room camera may also be plugged in, so let people pick the laptop webcam.
async function listCameras() {
  const devices = (await navigator.mediaDevices.enumerateDevices()).filter((d) => d.kind === "videoinput");
  const current = stream && stream.getVideoTracks()[0].getSettings().deviceId;
  camSelect.innerHTML = devices.map((d, i) =>
    `<option value="${d.deviceId}" ${d.deviceId === current ? "selected" : ""}>${d.label || `Camera ${i + 1}`}</option>`
  ).join("");
}

function wait(ms) { return new Promise((r) => setTimeout(r, ms)); }

// Crop the square inside the guide box out of the current video frame.
function grab() {
  const vw = video.videoWidth, vh = video.videoHeight;
  if (!vw || !vh) return null;
  const box = video.getBoundingClientRect();
  const scale = Math.max(box.width / vw, box.height / vh); // object-fit: cover
  const side = (GUIDE * box.width) / scale;
  const sx = (vw - side) / 2, sy = (vh - side) / 2;
  const c = document.createElement("canvas");
  c.width = c.height = CROP_SIZE;
  c.getContext("2d").drawImage(video, sx, sy, side, side, 0, 0, CROP_SIZE, CROP_SIZE);
  return c.toDataURL("image/jpeg", 0.85);
}

async function capture() {
  if (busy || !stream) return;
  busy = true;
  shots = [];
  renderShots();
  updateSave();
  const count = $("teach-count");
  $("teach-msg").textContent = "Get ready…";

  for (let n = 3; n > 0; n--) {
    count.textContent = n;
    sfx.tick(0.8);
    await wait(600);
  }
  count.textContent = "";
  dialog.classList.add("capturing");
  $("teach-msg").textContent = "Slowly turn it…";

  for (let i = 0; i < SHOTS; i++) {
    const img = grab();
    if (img) { shots.push(img); renderShots(); sfx.tick(1.3 + i * 0.05); }
    await wait(SHOT_GAP);
  }

  dialog.classList.remove("capturing");
  sfx.chime();
  $("teach-msg").textContent = `${shots.length} photos taken. Name it and save, or capture again.`;
  busy = false;
  updateSave();
  $("teach-name").focus();
}

function renderShots() {
  $("teach-shots").innerHTML = shots.map((s, i) => `<img src="${s}" alt="Photo ${i + 1}">`).join("");
}

function updateSave() {
  $("teach-save").disabled = busy || shots.length < 3 || !$("teach-name").value.trim();
}

async function save() {
  const name = $("teach-name").value.trim().toLowerCase();
  if (!name || shots.length < 3) return;
  $("teach-save").disabled = true;
  $("teach-msg").textContent = "Learning…";
  try {
    await api.teach(name, shots);
    sfx.laserSnap();
    $("teach-msg").textContent = `Learned "${name}". The room camera is now looking for it.`;
    await wait(1100);
    close();
  } catch (e) {
    $("teach-msg").textContent = `Couldn't save: ${e.message || e}`;
    updateSave();
  }
}
